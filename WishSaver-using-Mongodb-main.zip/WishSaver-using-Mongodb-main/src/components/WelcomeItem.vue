<template>
  <h1>Enter Details To Continue</h1>
</template>