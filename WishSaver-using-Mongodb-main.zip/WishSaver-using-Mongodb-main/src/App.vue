<script>
import HelloWorld from './components/HelloWorld.vue';
import WelcomeItem from './components/WelcomeItem.vue'
import WishForm from './components/WishForm.vue';
export default{
  components:{
    HelloWorld,WishForm
  }
}

</script>
<template>
  <main>
    
    <WishForm/>
    
  </main>
</template>